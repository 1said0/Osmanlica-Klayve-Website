# Proje Adı
Hayrat Osmanlıca Klavye

## Proje Amacı

Cîhan imparatorluğuna 13.yy'dan harf devrimine kadar haberleşmeyi sağlayan Osmanlı Türkçesi, kimi kaynaklar tarafından Türk tarihinin son 1000 yılına yakın bir dönem bu yazı ile yazılmış olduğu için araştırmacılar, edebiyatçılar ve tarihçiler tarafından birinci derecede önemli ve bilinmesi zorunlu bir alfabe olarak nitelenir.

Yoğun olarak Arap harflerini kullanarak yazı yazma ve haberleşme olanağı sağlayan Osmanlı Türkçesi'nin Kur'an-ı Kerim harflerini yaşatma imkanını tanıması bize en büyük motivasyon kaynağı oluyor.

Tüm bu sebepler bir araya gelince macOS’da ki Osmanlıca klavye eksikliği bizi bu problemi çözmeye itti ve yola çıktık.

## Yapım Yolu

 Ukelele’nin 3.5.2 versiyonunu kullandım.

(https://suragch.medium.com/how-to-make-a-custom-keyboard-for-mac-os-c9f607428372) kaynağından yardım aldım. Kaynakta harfi harfine tüm adımlar yer alıyor. (Boşluk tuşunu tanımlamayı unutmayın.) 

sh dosyası hazırlarken (https://github.com/create-dmg/create-dmg) kaynağından yardım aldım.

create-dmg \

  --volname "Application Installer" \           -- Birim adını ayarlama (Finder kenar çubuğunda ve pencere başlığında görüntülenir)
  
  --background "installer_background.png” \     -- Klasör arka plan resmini ayarla (png, gif, jpg sağlayın)
  
  --window-pos 200 120 \                        -- <x> <y>: Klasör penceresinin konumunu ayarla
  
  --window-size 800 400 \                       -- <width> <height>: Klasör penceresinin boyutunu ayarlar
  
  --icon-size 100 \                             -- Pencere simgeleri boyutunu ayarla (128'e kadar)
   
  --icon “OsmanlicaKlavye.app” 200 190 \        -- <x> <y>: Dosya simgesinin konumunu ayarla
  
  --hide-extension “OsmanlicaKlavye.app" \      -- Dosya uzantısını gizle
  
  --app-drop-link 600 185 \ß                    -- <x> <y>: x, y Konumunda Uygulamalar'a bir bırakma bağlantısı oluşturun
  
  "Application-Installer.dmg" \                 
  “Source/"

