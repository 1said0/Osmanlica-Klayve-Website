#!/usr/bin/env bash
create-dmg \
    --volname "Application Installer" \
    --background "installer_background.png" \
    --window-pos 200 200 \
    --window-size 1024 768 \
    --icon-size 100 \
    --icon "OsmanlicaKlavye.app" 275 575 \
    --hide-extension "OsmanlicaKlavye.app" \
    --app-drop-link 760 570 \
    "osmanlıca-klavye.dmg" \
    "Source/"


